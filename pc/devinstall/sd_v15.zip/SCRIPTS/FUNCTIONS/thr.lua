local function init()
end

local function run()
  local thr = math.floor((getOutputValue(2) + 1024) * 200 / 2048)
  local ail = math.abs(getOutputValue(0)) * 200 / 2048
  local ele = math.abs(getOutputValue(1)) * 200 / 2048
  local rud = math.abs(getOutputValue(3)) * 200 / 2048

  local r, g, b
  if thr <= 5 and ail <= 5 and ele <= 5 and rud <= 5 then
    r = 9
    g = 3
    b = 1
  else
    r = thr
    g = ail + ele
    b = rud + ele
  end

  for i = 0, LED_STRIP_LENGTH - 1, 1 do
    setRGBLedColor(i, r, g, b)
  end
  applyRGBLedColors()
end

local function background()
  -- Called periodically while the Special Function switch is off
end

return { run=run, background=background, init=init }
