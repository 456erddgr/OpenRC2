-------------------------------------------------------------------------------
-- TBS Agent 1.02 EDGETX Widget
-- release date: 2026-02
-- author: JimB40
-------------------------------------------------------------------------------
local DIR = '52/'
local LV = _VERSION
if LV ~= nil then
  local LM,LS = string.match(_VERSION,'^Lua (%d+)%.(%d+)')
  DIR = tonumber(LS) > 2 and '53/' or DIR
end
local SP = '/SCRIPTS/TOOLS/TBSAGENT/'
local API = loadScript(SP..DIR..'widget','Tx')(SP,DIR)
return API
